=== Education Web ===

Education web is an attractive, modern, easy to use and responsive WordPress education theme with colorful design and stunning flexibility . This theme is capable of tackling the overall needs of all educational institute websites including universities, colleges, schools and others. This theme will help you to create very high quality educational website easily with no time at all.

Contributors: offshorethemes

Tags : left-sidebar, right-sidebar, custom-background, custom-colors, custom-header, custom-menu, custom-logo, featured-images, footer-widgets, full-width-template, theme-options, threaded-comments, translation-ready, education


Requires at least: 4.7
Tested up to: 4.9.5
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Education web is an attractive, modern, easy to use and responsive WordPress education theme with colorful design and stunning flexibility . This theme is capable of tackling the overall needs of all educational institute websites including universities, colleges, schools and others. This theme will help you to create very high quality educational website easily with no time at all.


== Translation ==

education-web theme is translation ready.


== Copyright ==

Education web WordPress Theme, Copyright (C) 2017, offshorethemes
Education web is distributed under the terms of the GNU GPL


== License ==

* Based on Sparkle Themes https://sparklewpthemes.com/, (C) 2016 Sparkle Themes, [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css https://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](https://opensource.org/licenses/MIT)


Font Awesome 4.7.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

@preserve HTML5 Shiv 3.7.3
@afarkas @jdalton @jon_neal @rem
MIT/GPL2 Licensed

Respond.js
min/max-width media query polyfill. (c) 
Scott Jehl
MIT Lic. j.mp/respondjs

WP Bootstrap Navwalker V2.0.5 ( Edward McIntyre - @twittem, WP Bootstrap )
https://github.com/wp-bootstrap, GitHub Plugin URI: https://github.com/wp-bootstrap/wp-bootstrap-navwalker
Licensed GPL-3.0+ (https://www.gnu.org/licenses/gpl-3.0.txt)

BreadcrumbTrail, V1.0.0
Justin Tadlock <justin@justintadlock.com>
Copyright (c) 2008 - 2015, Justin Tadlock
http://themehybrid.com/plugins/breadcrumb-trail
License   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

bxSlider v4.2.12
Copyright 2013-2015 Steven Wanderski
Written while drinking Belgian ales and listening to jazz
Licensed under MIT (http://opensource.org/licenses/MIT)


jQuery OwlCarousel v1.3.3
Copyright (c) 2013 Bartosz Wojciechowski
http://www.owlgraphic.com/owlcarousel/
Licensed under MIT


animate.css -http://daneden.me/animate
Version - 3.5.2
Licensed under the MIT license - http://opensource.org/licenses/MIT
Copyright (c) 2017 Daniel Eden


jquery.counterup.js 1.0
Copyright 2013, Benjamin Intal http://gambit.ph @bfintal
Released under the GPL v2 License
Date: Nov 26, 2013


Theia Sticky Sidebar v1.6.0
https://github.com/WeCodePixels/theia-sticky-sidebar
Glues your website's sidebars, making them permanently visible while scrolling.
Copyright 2013-2016 WeCodePixels and other contributors
Released under the MIT license


Class: prettyPhoto
Use: Lightbox clone for jQuery
Author: Stephane Caron (http://www.no-margin-for-errors.com)
Version: 3.1.6


Sticky Plugin v1.0.4 for jQuery
Author: Anthony Garand
Improvements by German M. Bravo (Kronuz) and Ruud Kamphuis (ruudk)
Improvements by Leonardo C. Daronco (daronco)
Created: 02/14/2011
Date: 07/20/2015
Website: http://stickyjs.com/


Waypoints - 4.0.0
Copyright © 2011-2015 Caleb Troughton
Licensed under the MIT license.
https://github.com/imakewebthings/waypoints/blob/master/licenses.txt



Image used in screenshot and banner

https://www.pexels.com/photo/accomplishment-ceremony-education-graduation-267885/   - License CC0 Public Domain


== Installation ==
    
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Frequently Asked Questions ==


== Changelog ==

= 1.0.6 20th April 2018 =

** Add theme info in admin panle.
** Add Upgreate pro verion options in customizer.

= 1.0.5 12th April 2018 =

** Modification made on hook to select frontpage.

= 1.0.4 19th March 2018 =

** Fixed review list issue.


= 1.0.3 16th March 2018 =

** Fixed review list issue.


= 1.0.2 3rd March 2018 =

** Fixed Design Issue.

= 1.0.1 23th January 2018 =

** Fixed Design Issue.
** Add 11 different widget area.
** Make theme compatible with woocommerce, Contact Form 7 and Page Builder by SiteOrigin external plugins.

= 1.0.0 =

** Submitted theme for review in http://wordpress.org